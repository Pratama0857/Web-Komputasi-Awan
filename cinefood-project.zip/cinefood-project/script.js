// =====================
// DATA MENU
// =====================
const MENU = [
  { id: 1,  name: 'Popcorn Caramel',      desc: 'Popcorn manis karamel ukuran large',        price: 35000, cat: 'Snack',   emoji: '🍿' },
  { id: 2,  name: 'Popcorn Salted Butter', desc: 'Popcorn gurih mentega ukuran large',        price: 32000, cat: 'Snack',   emoji: '🍿' },
  { id: 3,  name: 'Nachos + Cheese',       desc: 'Nachos renyah dengan saus keju cheddar',    price: 42000, cat: 'Snack',   emoji: '🧀' },
  { id: 4,  name: 'Hotdog Classic',        desc: 'Sosis sapi, saus tomat & mustard',          price: 38000, cat: 'Makanan', emoji: '🌭' },
  { id: 5,  name: 'Burger Crispy',         desc: 'Ayam crispy dengan saus mayo spesial',      price: 55000, cat: 'Makanan', emoji: '🍔' },
  { id: 6,  name: 'Nugget 6 pcs',          desc: 'Nugget ayam crispy dengan saus sambal',     price: 30000, cat: 'Makanan', emoji: '🍗' },
  { id: 7,  name: 'Coca-Cola',             desc: 'Minuman bersoda segar ukuran large',        price: 22000, cat: 'Minuman', emoji: '🥤' },
  { id: 8,  name: 'Fanta Strawberry',      desc: 'Minuman soda rasa stroberi segar',          price: 22000, cat: 'Minuman', emoji: '🧃' },
  { id: 9,  name: 'Air Mineral',           desc: 'Aqua 600ml dingin',                         price: 10000, cat: 'Minuman', emoji: '💧' },
  { id: 10, name: 'Kopi Susu',             desc: 'Kopi susu creamy ala kekinian',             price: 28000, cat: 'Minuman', emoji: '☕' },
  { id: 11, name: 'Ice Cream Cone',        desc: 'Vanilla + coklat, cone renyah',             price: 25000, cat: 'Dessert', emoji: '🍦' },
  { id: 12, name: 'Churros + Coklat',      desc: 'Churros hangat dengan saus coklat',         price: 35000, cat: 'Dessert', emoji: '🍩' },
];

// =====================
// STATE
// =====================
let cart = {};
let userName = '';
let userSeat = '';
let userStudio = '';
let currentFilter = 'Semua';

// =====================
// HELPERS
// =====================
function formatRp(n) {
  return 'Rp ' + n.toLocaleString('id-ID');
}

// =====================
// LOGIN & LOGOUT
// =====================
function doLogin() {
  const name    = document.getElementById('inputName').value.trim();
  const seat    = document.getElementById('inputSeat').value.trim().toUpperCase();
  const studio  = document.getElementById('inputStudio').value;

  if (!name || !seat || !studio) {
    alert('Lengkapi semua data ya!');
    return;
  }

  userName  = name;
  userSeat  = seat;
  userStudio = studio;

  document.getElementById('userName').textContent  = name.split(' ')[0];
  document.getElementById('userSeat').textContent  = `${studio} · ${seat}`;
  document.getElementById('userAvatar').textContent = name.charAt(0).toUpperCase();

  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appScreen').classList.add('active');

  renderMenu();
}

function doLogout() {
  cart = {};
  document.getElementById('loginScreen').style.display = '';
  document.getElementById('appScreen').classList.remove('active');
  document.getElementById('inputName').value    = '';
  document.getElementById('inputSeat').value    = '';
  document.getElementById('inputStudio').value  = '';
}

// =====================
// MENU
// =====================
function filterMenu(cat, btn) {
  currentFilter = cat;
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderMenu();
}

function renderMenu() {
  const grid     = document.getElementById('menuGrid');
  const filtered = currentFilter === 'Semua'
    ? MENU
    : MENU.filter(m => m.cat === currentFilter);

  grid.innerHTML = filtered.map(item => {
    const qty = cart[item.id] ? cart[item.id].qty : 0;
    return `
      <div class="menu-card ${qty > 0 ? 'in-cart' : ''}" id="card-${item.id}">
        ${qty > 0 ? `<div class="in-cart-badge">${qty}x</div>` : ''}
        <span class="item-emoji">${item.emoji}</span>
        <div class="item-name">${item.name}</div>
        <div class="item-desc">${item.desc}</div>
        <div class="item-footer">
          <div class="item-price">${formatRp(item.price)}</div>
          ${qty > 0
            ? `<div class="qty-control">
                <button class="qty-btn" onclick="changeQty(${item.id}, -1)">−</button>
                <span class="qty-num">${qty}</span>
                <button class="qty-btn" onclick="changeQty(${item.id}, 1)">+</button>
               </div>`
            : `<button class="add-btn" onclick="addToCart(${item.id})">+</button>`
          }
        </div>
      </div>`;
  }).join('');
}

// =====================
// CART ACTIONS
// =====================
function addToCart(id) {
  const item = MENU.find(m => m.id === id);
  if (!cart[id]) cart[id] = { ...item, qty: 0 };
  cart[id].qty++;
  updateCartCount();
  renderMenu();
}

function changeQty(id, delta) {
  if (!cart[id]) return;
  cart[id].qty += delta;
  if (cart[id].qty <= 0) delete cart[id];
  updateCartCount();
  renderMenu();
  if (document.getElementById('cartPanel').classList.contains('active')) {
    renderCart();
  }
}

function updateCartCount() {
  const total = Object.values(cart).reduce((s, i) => s + i.qty, 0);
  document.getElementById('cartCount').textContent = total;
}

// =====================
// CART PANEL
// =====================
function openCart() {
  document.getElementById('cartOverlay').classList.add('active');
  document.getElementById('cartPanel').classList.add('active');
  renderCart();
}

function closeCart() {
  document.getElementById('cartOverlay').classList.remove('active');
  document.getElementById('cartPanel').classList.remove('active');
}

function renderCart() {
  const items  = Object.values(cart);
  const body   = document.getElementById('cartBody');
  const footer = document.getElementById('cartFooter');

  if (items.length === 0) {
    body.innerHTML = `
      <div class="cart-empty">
        <i class="ti ti-shopping-cart-off"></i>
        <p>Keranjangmu masih kosong.<br>Yuk pilih menu dulu!</p>
      </div>`;
    footer.style.display = 'none';
    return;
  }

  body.innerHTML = items.map(item => `
    <div class="cart-item">
      <span class="cart-item-emoji">${item.emoji}</span>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">
          ${formatRp(item.price)} × ${item.qty} = ${formatRp(item.price * item.qty)}
        </div>
      </div>
      <div class="cart-item-qty">
        <button class="qty-btn" onclick="changeQty(${item.id}, -1)">−</button>
        <span class="qty-num">${item.qty}</span>
        <button class="qty-btn" onclick="changeQty(${item.id}, 1)">+</button>
      </div>
    </div>
  `).join('');

  const subtotal  = items.reduce((s, i) => s + i.price * i.qty, 0);
  const delivery  = 5000;
  const total     = subtotal + delivery;
  const totalQty  = items.reduce((s, i) => s + i.qty, 0);

  document.getElementById('cartSummary').innerHTML = `
    <div class="summary-row">
      <span>Subtotal (${totalQty} item)</span>
      <span>${formatRp(subtotal)}</span>
    </div>
    <div class="summary-row">
      <span><i class="ti ti-armchair" style="font-size:12px;vertical-align:-1px"></i> Biaya antar ke kursi</span>
      <span>${formatRp(delivery)}</span>
    </div>
    <div class="summary-row total">
      <span>Total</span>
      <span>${formatRp(total)}</span>
    </div>
  `;

  footer.style.display = 'block';
}

// =====================
// ORDER
// =====================
function placeOrder() {
  const orderNum = '#CIN' + Math.floor(1000 + Math.random() * 9000);
  document.getElementById('orderNum').textContent   = orderNum;
  document.getElementById('deliverTo').textContent  = `${userStudio}, Kursi ${userSeat} — ${userName}`;
  closeCart();
  document.getElementById('successScreen').classList.add('active');
  cart = {};
  updateCartCount();
}

function backToMenu() {
  document.getElementById('successScreen').classList.remove('active');
  renderMenu();
}
